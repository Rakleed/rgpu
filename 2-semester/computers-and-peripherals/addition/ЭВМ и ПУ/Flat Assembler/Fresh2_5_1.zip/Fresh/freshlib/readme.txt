 _______________________________________________________________________________________
|                                                                                       |
| ..::FreshLib::..  Free, open source. Licensed under "BSD 2-clause" license."          |
|                                                                                       |
| (c)2003, 2004, 2005, 2010, 2011, 2012 Fresh developement team                         |
|_______________________________________________________________________________________|

FreshLib is standard Fresh IDE library. FreshLib contains macros, 
equates and code to allow writing of portable applications.

FreshLib is free, open source project, distributed under the terms of 
"BSD 2-clause license". The text of the license is in the file "License.txt"

FreshLib is created and maintained by Fresh development team. Every member of the team
have some contribution to the project. Here is the list of people contributed to the
project (in order of appearance; newer first):

vid
pelaillo
scientica (Fredrik Klasson)
tommy 	  (Tommy Lilehagen)
VeSCeRa	  (Yunus Sina Gulsen)
roticv	  (Victor Loh)
decard 	  (Mateusz Tymek)
John Found 

Special thanks to Tomasz Grysztar for creating FASM.
Tomasz also provided some really useful macros.
_________________________________________________________________________________________

For additional information about Fresh and FreshLib, look at following locations:

http://fresh.flatassembler.net	- main site of the project Fresh.
http://board.flatassembler.net	- Flat assembler message board.
_________________________________________________________________________________________

The test project for FreshLib is "TestFreshLib.fpr"
You can compile and run it as Win32, or as Linux application. 
Use Fresh IDE or compile TestLib.asm file with FASM compiler.

