#!/bin/bash

function test {
    "$@"
    status=$?
    if [ $status -ne 0 ]; then
        echo "error with $1"
    fi
    return $status
}

test xdg-icon-resource install --context mimetypes --size 16 ./x-asmsrc.png text-x-asmsrc
test xdg-icon-resource install --context mimetypes --size 32 ./x-asmsrc.png text-x-asmsrc
test xdg-icon-resource install --context mimetypes --size 16 ./x-freshproject.png application-x-freshproject
test xdg-icon-resource install --context mimetypes --size 32 ./x-freshproject.png application-x-freshproject

test xdg-mime install x-asmsrc.xml
test xdg-mime install x-freshproject.xml