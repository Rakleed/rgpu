Portable console application, based on FreshLib. 
Can be compiled as PE executable or as ELF executable, without source changes.

In order to keep it portable, use only FreshLib functions and avoid use of OS specific API.