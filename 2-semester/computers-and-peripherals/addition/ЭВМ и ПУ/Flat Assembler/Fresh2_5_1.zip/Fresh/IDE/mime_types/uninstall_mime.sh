#!/bin/bash

function test {
    "$@"
    status=$?
    if [ $status -ne 0 ]; then
        echo "error with $1"
    fi
    return $status
}

test xdg-icon-resource uninstall --context mimetypes --size 16 text-x-asmsrc
test xdg-icon-resource uninstall --context mimetypes --size 32 text-x-asmsrc
test xdg-icon-resource uninstall --context mimetypes --size 16 application-x-freshproject
test xdg-icon-resource uninstall --context mimetypes --size 32 application-x-freshproject

test xdg-mime uninstall ./x-asmsrc.xml
test xdg-mime uninstall ./x-freshproject.xml