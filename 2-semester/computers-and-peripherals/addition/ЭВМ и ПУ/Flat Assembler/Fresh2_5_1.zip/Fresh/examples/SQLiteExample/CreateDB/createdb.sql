create table Pictures (
  ID integer primary key autoincrement,
  FromSun integer,
  Name    text,
  Description text,
  Picture blob
);