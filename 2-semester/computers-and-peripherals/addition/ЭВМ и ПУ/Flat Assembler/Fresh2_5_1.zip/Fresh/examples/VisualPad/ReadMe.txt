    This is small Notepad like program,
created using Fresh visual design and 
Fresh graphic libraries for menues
and toolbars.