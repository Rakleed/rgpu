This example creates database with the images from the directory "PICTURES".
In order to run it you need the file "sqlite3.dll" that is placed one 
directory up in the tree. Simply copy it here or in some of the system 
directories, as Windows/system32 ; Windows/system ; etc.