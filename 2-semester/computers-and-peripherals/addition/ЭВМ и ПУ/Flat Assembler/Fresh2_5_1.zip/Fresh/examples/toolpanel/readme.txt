This example creates some simple tool window that auto hides itself to the left edge of the screen.
When the user points to the panel it pops out.
Something like autohide Windows task bar.