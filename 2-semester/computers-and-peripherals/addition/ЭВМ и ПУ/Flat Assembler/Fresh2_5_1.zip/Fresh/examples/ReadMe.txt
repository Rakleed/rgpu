IMPORTANT:
These examples are intended to be open and compile from this directory.
They expect that the include libraries will be located in "../../include"
and "../../freshlib/" directories.
It was made in order to ensure compilation even if Fresh IDE is not set up 
properly.
If you want to copy these projects somewhere and to play with them, you
have to edit the options of the project (Project|Project options) and to
remove "finc" and "lib" aliases from the list.

simple.asm
~~~~~~~~~~
Very simple "Hello world" Win32 GUI application, it doesn't use any
includes, so you can compile and run it with Fresh even if it is not 
configured properly.


Arrays\
~~~~~~~
  Example how to create and use initialized arrays of structures in 
FASM/Fresh.


Char count\
~~~~~~~~~~~
  Windows program that counts characters typed in edit box.


ElfExe\
~~~~~~~
  Simple "Hello world" application for Linux.
In order to run it in Windows you need to install andLinux distribution - 
see on "www.andlinux.org" and to set its path in Fresh IDE options.

In Linux, the application can be run natively.


Fractal\
~~~~~~~~
  Good example how powerfull is FASM compiler. This project creates 
not an executable file, but .tga image file. You can view it using 
any graphic editor/viewer.


HotButton\
~~~~~~~~~~
  Demonstrates how to create simple "Hot" buttons - i.e. the button
changes its look when the mouse pointer hovers over it.


ScrollBox\
~~~~~~~~~~
  Example how to create Windows with scrollable client area using 
standard Fresh libraries.


SEH\
~~~
  Example how to use structured exception handling libary
in assembly programs.

SQLiteExample\
~~~~~~~~~~~~~~

  Demonstrates how to use SQLite library for work with relational
databases.

VisualPad\
~~~~~~~~~~
  Simple project for Notepad like text editor, using Fresh GUI
library. Not finished, but you can use it as a example for project
created with current Fresh visual programming features.

ToolPanel\
~~~~~~~~~~

  Simple tool panel, that hides itself when not needed.
Demonstrates use of timers and how to handle mouse messages.

XLib\
~~~~
  Simple GUI application for Linux. This example is stand alone
and does not depend on Fresh include files.
  Demonstrate the use of XLib in Linux.
