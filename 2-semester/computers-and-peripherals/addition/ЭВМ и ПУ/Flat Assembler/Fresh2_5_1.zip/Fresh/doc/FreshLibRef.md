FreshLib reference
# Chapter 6 FreshLib reference

## Overview 

FreshLib is an assembly library aimed to ease the development of assembly
language applications, freely portable between different platforms,
such as Win32 or Linux.

The library is coded in [FASM][flat assembler] syntax
and is intended to be easily used within [Fresh IDE],
although it could be used for plain FASM development.

The library consists of two layers: one, that is OS dependent and
a second one that is OS independent. The OS dependent layer is very
small, in order to help porting it for different OSes. This layer
only makes interface to the core OS functions, such as memory allocations,
file access, drawing functions, simple window management etc.

The OS independent layer is responsible for the main application functionality
allowing creation of different kind of windows and controls, processing of the
system messages, work with dynamic strings, arrays and other data processing.

FreshLib is mainly intended for developing GUI applications, as they
are the most challenging to be ported across different platforms.
FreshLib is also created with visual programming in mind, so it contains
a flexible, event driven and OS independent template engine allowing
visual creation of application user interfaces.

FreshLib is in early development stage and probably will be changed
many times in order to reach their objectives: to be small, fast and
easy to use.

The main intention is to keep the bloat off the library, but containing
all necessary accessories for comfortable programming of a very wide
range of applications.

The architecture of FreshLib is open and it can be freely expanded
with other libraries without increasing the size of applications.
In other words, only those parts of the library that are effectively
used will be compiled on the final executable.

------------------------------------------------------------------------

## About this manual 

This manual is a "work in progress". Any
part of it can be changed at any time.

Of course, some of the libraries described in this document are more
stable and finished like the macro, system and data libraries. Therefore,
the chapters about these libraries are less likely to be changed.
Other libraries (like graphics and GUI), will be heavily modified
so the manual will be changed accordingly.


------------------------------------------------------------------------

## Structure of the library. 

FreshLib contains many code and macros libraries, structured hierarchically
and depending on each other. Here is shown a part of the library directory tree:
;begin
    freshlib/
        compiler/
            Linux/
            Win32/
        data/
            Linux/
            Win32/
        dialogs/
            Linux/
            Win32/
        ...
;end
The library is structured to support different platforms transparently.
You can see, that the tree consists of main sub-directories, that
contains OS independent libraries, separated by topics.
For example *system* subdirectory contains libraries for accessing system
resources such as memory, files, etc. *data* contains libraries for data
handling and so on.
Every topic directory have also several sub-directories, that contains OS
dependent code these directories are named after the platform they serve. 
(In this moment only Linux and Win32 OSes are supported).

------------------------------------------------------------------------

## Compiler setup for FreshLib use.

You can use any FASM compiler to compile applications that uses FreshLib.
In order to be compiled properly, FreshLib needs environment variables
named `lib` and `TargetOS` to be defined.

The variable `lib` contains the path to the main directory of FreshLib
and the variable `TargetOS` contains the target platform, the application
will be compiled for. The value of `TargerOS` is identical to the name of
OS dependent directories in FreshLib.

There are several ways these variables to be defined, depending on
the compiler you use [FASM], [FASMW] or [Fresh IDE].

1. These variable can be defined in the OS environment - see your OS 
documentation for details. this approach is more universal - it works for all 
kind of FASM compilers. The main drawback is that you have to use OS specific 
commands and probably will have to edit some system files.

1. Definition in the section `[environment]` of *"fasm.ini"* or *"Fresh.ini"* 
file, depending on the IDE you are using. This approach works for both FASMW 
and Fresh IDE, but in Fresh, the same effect can be done from inside the IDE. 
Besides, defined this way, the environment variables becomes "global" - active 
for all projects compiled with FASMW or Fresh.

1. From inside Fresh IDE.

In Fresh IDE, the environment variables are named *alias*, because they serve 
to provide short alias for the file paths. Two types of alias (environment 
variables) lists are supported by Fresh: *global aliases* and *project 
aliases*. Global aliases are defined in the IDE options dialog: *Options|IDE 
options|Aliases*. Here is the screenshot of this dialog:

  [!_images/AliasesDlg.png][IDE options dialog, section "Aliases"]

The global aliases are active for every project compiled with Fresh and are 
stored in the Fresh.ini file, inside the Fresh program directory.

Project aliases are defined in the Project options dialog: *Project|Project 
options* or from the project manager, click on the button *Settings* at the top 
and select *Project options*. The project options dialog is shown on the 
following screenshot:

  [!_images/ProjectOptions.png][Project based aliases can be edited in the project options dialog.]

The project aliases are stored inside the project file (.fpr) and they are 
project specific.

For FreshLib it is not important what list will be used, but it is more 
convenient for `lib` variable to be defined in the global list and for 
`TargetOS` variable to be defined in the project aliases. In such way the 
common parameter (the place of the library) will be set once for all projects, 
and the particular parameter (the target OS) will be set separately for every 
project.

Also, there is very convenient way of changing the value of project aliases — 
if several values are specified in the project alias, separated with `|` char 
(for example: `Win32|Linux`), Fresh will provide fast switching between these 
values from the project manager options menu, as shown on the picture:

   [!_images/fastswitch.png][The aliases with more than one value will appear in the popup menu for fast changing.]

When Fresh searches for needed alias names, during the compilation, it searches 
first in the project aliase list, then the global aliases and at the end, the 
OS environment variables. Of course, if the alias is not found on these places, 
the compilation fails with error.


[FASM] http://flatassembler.net

[FASMW] http://flatassembler.net

[Fresh] http://fresh.flatassembler.net

[Fresh IDE] http://fresh.flatassembler.net

------------------------------------------------------------------------

## FreshLib compiling options 

FreshLib uses some options in order to set the behavior of the compiler and the 
different macro libraries. These options are defined as a local constants of 
the label *"options."* Here is a list:

[#options.FastEnter] `options.FastEnter` controls the behavior of the [#proc] macro.

When *options.FastEnter = 1* the procedure entry/leave code will be created 
with faster, but bigger push ebp/pop ebp instructions.

When *options.FastEnter = 0* — enter/leave instructions are used.

[#options.ShowSkipped] `options.ShowSkipped` controls the information displayed 
during compilation.

When *options.ShowSkipped = 1* the compiler will display in the output window 
the procedures that are not compiled because they are not used in the program.

[#options.ShowSizes] `options.ShowSizes` controls the behaviour of the DispSize 
macro.

When *options.ShowSizes = 0* the macro [#DispSize] will be disabled.

[#options.DebugMode] `options.DebugMode` controls the behaviour of the debug macros.

When *options.DebugMode = 1* the macros from [#simpledebug] library will generate debug code and
debug console will be created on running the application.

When *options.DebugMode = 0* these macros will not generate code and the debug console will not be
created.

------------------------------------------------------------------------

## FreshLib code conventions 

### Naming conventions 

1. The names prefixed with one or more underscores ("_") are not recomended for use by the user.
These are internaly used labels that can be changed later. More underscores in the prefix - 
more "internal" is the given identifier.

For example one underscore ( like this: `_AlmostPrivate`) means - "use it carefully". 

Three underscores (for example `___SomeVeryPrivateLabel`) means - don't use it at all. 
It is for internal use only and will be changed later!

2. The names are considered to be used with code completion editor - i.e. there is no long equal 
prefixes of the names, but there are short "class" prefixes.
For example most of the procedures in StrLib begin with "Str" prefix. 

3. In general, FreshLib uses [CamelCase] naming convention, with constants in lowerCamelCase and 
procedures in HigherCamelCase.

4. All local labels and procedure arguments are prefixed with dot — ".";

5. Almost all of the [#struct] and all of [#object] definitions are prefixed with "T" prefix — for 
example [#TTimer] or [#TButton]

6. The file names convention. All file names with extension `.inc` doesn't contain any code or
data definition. Only macro and constants definitions are permitted.

The files with '.asm' extension can define code and data. Although, the code and data in FreshLib
can exists in the compiled binary, only if they are used. Not used data or code, included in
the binary should be considered a bug.

[CamelCase]  http://en.wikipedia.org/wiki/CamelCase


### Register preserving convention

1. The rule is - preserve all you are using. All procedures in FreshLib preserves all registers, 
except these used for returning result values.

;quote
Note: There is some small retreat from this rule - in the object handling procedures, some register 
are preserved internaly, so the object class procedures may not preserve them. 
See [#object.asm] library for details.

Another exception are the user defined callbacks - FreshLib always preserves the registers before calling
callback procedures and restores after that.
;end

2. CF is widely used for returning error status or boolean result. 
As a rule *CF=0* means no error; *CF=1* means error.

The use of CF is described always in the description of the respective procedures.

3. The procedures can return result in more than one register. As a rule, EAX is the result register 
for the most procedures, but sometimes other registers are used - in order to provide better 
interface for assembly programming.

For example number of procedures return X,Y values in EAX, EDX registers.

* EAX — commonly used for returning 32bit values;

* EDX — second choise - used together with EAX for 64 bit values, or as a second returned value.

* ECX — usually some count. For example if EAX returns pointer to some memory, ECX will contains the 
data size. See [#LoadBinaryFile] for example.

------------------------------------------------------------------------

## Using FreshLib

There are only two files, the user should include in order to use FreshLib. They are both located
in the "freshlib" directory, usually referred by %lib% directory alias.

These files are:

* `%lib%/freshlib.inc` - contains all macro and OS dependent equates definitions.

* `%lib%/freshlib.asm` - contains all code of FreshLib. Only the used code will actually be included
in the result binary.

The minimal application with FreshLib have following code:

;begin
include "%lib%/freshlib.inc"

@BinaryType GUI, compact

include "%lib%/freshlib.asm"

start:
        InitializeAll

        ; Place your code here

        FinalizeAll
        stdcall TerminateAll, 0
;end

The macro [#@BinaryType] will be explained later in the 
next chapter.

------------------------------------------------------------------------
## Data definitions in FreshLib program

FreshLib uses advanced data definitions macros, that allows data definitions to be mixed with the 
code, but then to be grouped and inserted in the data section of the program.
This kind of definitions greatly improves the readability of the program, because keeps the data
near to the code that uses it. It is especially important on big projects where the code is spreaded
among multiply files.
There are two main types of data - uninitialized and initialized data.

The initialized data definitions are enclosed inside [iglobal], [endg] macros and the uninitialized 
data in [uglobal], [endg] macros. Inside these blocks you can use all FASM data definition directives
or any other valid FASM code. Note only, that in `uglobal` block only the size of the data matters, 
if you use some defined data, the values will be lost.

;begin
iglobal
  MyGlobalVar dd 123, 456, 789
endg

uglobal
  SomeUndefinedVar rd 1
  SomeArray        rb 256
endg

;end

Another useful macro is [text] (actually it is `struc`). It defines some string constant anywhere in
the source code. The string constant is later defined in the data section of the program.

When used data definition macros, all the data is actually defined at the end of the program. The structure of 
the data definition dependds on the type of the compiled program and the options set in @BinaryType statement.

------------------------------------------------------------------------

## FreshLib directory "compiler/"

This directory contains only one macro library: *"executable.inc"*

### "executable.inc" library 

This library defines the macros that are going to be used for creating the main structure of
the program. The implementation of these macros is OS dependent, as long as the type of the
executable file is OS dependent: PE for Win32 and ELF for Linux. The use of the library, however
is OS independent and is common for all supported OSes.
Depending on the value of `TargetOS` alias, the library will create PE executable or DLL
`(%TargetOS%='Win32')`, or ELF executable or shared library `(%TargetOS%='Linux')`

*NOTE:* Every of the macros from this library must be used only once in the program.

--------------

[#@BinaryType] `macro @BinaryType type, model`

This macro sets the type of the executable. The argument `type` can accept one of the following
values: `GUI`, `console` or `DLL`. The argument `model` can be one of `default`, `compact` and `manual` and
determines the memory structure of the compiled binary. 

When `model equ default`, the data is defined in separate segments/sections, depending on the binary format used.

When `model equ compact`, the data is defined as compact as possible. For example, if allowed by the format, the
data is defined in the code segment/section, immediately after the code.

When `model equ manual`, no data is automatically defined, but the user must use somewhere in the source [IncludeAllGlobals] macro. On that place all data will be defined. Notice, that the user should use `IncludeAllGlobals`
*only* when `model` argument is equal to `manual`.

Actually `model` argument is optional. If missing, value of `default` is assumed.

This macro also begins the main code section of the executable and defines the entry label of the 
program. The entry label is fixed to `start:`.

For example, following code will tell the compiler to compile the program as a GUI application with compact memory structure:
;begin
      include '%lib%/freshlib.inc'
      @BinaryType GUI, compact
;end

--------------

## FreshLib directory "equates/"

[#allequates.inc] *"allequates.inc"* library. This library defines all
constants and structures needed for OS dependent parts of FreshLib.

Actually, the user should never use these constants and structures in the portable program.

The constants and structures that the user should use are defined in the respective libraries,
not in *"allequates.inc"*.

This library will be included automatically by "%lib%/freshlib.inc" file, so the user should not care
about this library at all.

------------------------------------------------------------------------

## FreshLib directory "imports/" 

[#allimports.asm]Another directory that contains only OS dependent definitions is *"imports/"* with a library
file to be included in the project: *"allimports.asm"*

This file is automatically included in the [#@AllImportSection] and [#@AllImportEmbeded] macros.
Then it will generate the proper import section, depending on the target platform and functions used 
by the OS dependent parts of FreshLib.

FreshLib contains very big catalog of shared libraries for Windows and decent set of Linux
shared libraries. The import macros used by FreshLib includes in the import section of the
program, only the functions used by the program, so it will never define redundant import items.

The user must never call directly imported functions from inside a portable application, except if
the imported dynamic library is portable as well. (as sqlite3.dll, for example)

------------------------------------------------------------------------

## FreshLib directory "macros/" 

This directory contains several libraries that provides common convenience functions to be
used with big assembly projects. 

All these libraries will be included automatically in "%lib%/freshlib.inc" file.

There is no overhead including all these libraries, because there is no code to be generated, 
just macro definitions. 
There is a little delay in compile time but thanks to fasm's speed, it is barely noticeable.

Lets examine each one of these libraries.

### "_stdcall.inc" library 

In general this library provides ways of definition and invocation of the procedures with
argument passing through the stack. It supports STDCALL and CCALL calling conventions.

-------------------

[#proc] `macro proc name, [arg]`
[#begin] `macro begin`
[#endp] `macro endp`
[#return] `macro return`
[#cret] `macro cret`
[#locals] `macro locals`
[#endl] `macro endl`

These macros define a procedure, create a stack frame for the local variables and define
symbolic names for the arguments. The macro "proc" defines the global label "name" as a name
for the procedure. All arguments and local variables are defined as a local labels with regard
to the name of the procedure. That is why all arguments and local variables must have names
beginning with dot.

Between the line with *proc* and *begin*, any number of local variables can be defined.
The macro *begin* marks the begining of the procedural code.

The macro *endp* marks the end of the procedural code.

The return from procedure instruction is provided by macros *return* or *cret* depending on
the calling convention we want to use: *return* clears the arguments from the stack and *cret*
does not.

Inside the procedure, a secondary stack frame can be allocated with the pair *locals* and *endl*.
All data definitions, enclosed between these macros will define a secondary stack frame that
is a continuation of the stack frame defined between *proc* and *begin*.

Any number of *locals* and *endl* pairs can be used, but all of these secondary stack frames
will overlap between each other. This feature is specially intended to provide savings of stack
space and at the same time, to provide talking variable names for the different parts of more
complex procedures.

For example (in Win32) let we have complex window procedure that have to process
multiple messages. 

One of the message handlers may need one variable `.rect`.

Another message handler may need two variables called `.point1` and `.point2`.

But the procedure as a whole is never going to need all those variables at the
same time, because it process only one message at a time. On the other hand it
may need the variable `.ctrldata` for every message processed. The optimal solution
is to define the variables as shown in the following example:

;begin
    proc CtrlWinProc, .hwnd, .wmsg, .wparam, .lparam
    .ctrldata dd ?
    begin
        invoke GetWindowLong, [.hwnd], GWL_USERDATA
        mov    [.ctrldata], eax

        cmp    [.wmsg], WM_MESSAGE1
        je     .message1
        cmp    [.wmsg], WM_MESSAGE2
        je     .message2
        return

    .message1:
    locals
      .rect RECT
    endl
        ; do something.
        return

    .message2:
    locals
      .point1 POINT
      .point2 POINT
    endl
        ; do something. 
        return
    endp
;end

The assignment of the stack memory for the above example is shown in the table:
;table
(1, 2) Address

(3, 1) Stack frames
;-----------------------
Common

Locals 1

Locals 2
;-----------------------
EBP-20

--

.rect.left

.point1.x
;-----------------------
EBP-16

--

.rect.top

.point1.y
;-----------------------
EBP-12

--

.rect.right

.point2.x
;-----------------------
EBP-8

--

.rect.bottom

.point2.y
;-----------------------
EBP-4

.ctrldata

--

--

;end

;;begin
;;+---------+---------+--------------+-------------+
;;|         |           Stack frames               |
;;+ address +---------+--------------+-------------+
;;|         |  common |   locals 1   |   locals2   |
;;|:-------:|:-------:|:------------:|:-----------:|
;;| EBP-20  |         | .rect.left   |   .point1.x |
;;| EBP-16  |         | .rect.top    |   .point1.y |
;;| EBP-12  |         | .rect.right  |   .point2.x |
;;| EBP-08  |         | .rect.bottom |   .point2.y |
;;| EBP-04  |.ctrldata|              |             |
;;+---------+---------+--------------+-------------+
;;        Procedure local labels memory map.
;;end

As you can see, *.rect* occupies the same memory as *.point1* and *.point2*,
but *.ctrldata* is never overlapped and exists independently.

As a general rule, you have to use the definitions between "proc" and "begin" for local
variables that are used in every call of the procedure and separate locals/endl definitions
for variables needed for the particular branches inside the procedure.
This approach will always provide the optimal size for the locals stack frame.

--------------------

[#initialize] `macro initialize`
[#finalize] `macro finalize`

The macros "initialize" and "finalize" defines one special type of procedures that, during
compilation are registered in a two separate lists - one for "initialize" and one for
"finalize" procedures. Procedures defined with "initialize" and "finalize" must have no any
arguments.

After that, using the macros "InitializeAll" and "FinalizeAll", all these procedures can be
call at once. "initialize" procedures are call in the order of their definition and "finalize"
procedures in reverse order.

These macros provides standard and consistent way for initialization and the
finalization of the libraries and modules of the application.

FreshLib uses this mechanism and the user is free to use it also.


-------------------------


[#stdcall] `macro stdcall proc, [arg]`
[#ccall]   `macro ccall proc, [arg]`
[#invoke]  `macro invoke proc, [arg]`
[#cinvoke] `macro cinvoke proc, [arg]`

These macros call the procedures with STDCALL and CCALL calling convention.

`stdcall` macro pushes the arguments to the stack in reverse order and then call
the procedure with label *proc*. As long as the macro "stdcall" does not provide
any stack cleanup (this duty is assigned to the procedure) the arguments can be
pushed in free manner using, for example, separate push instructions for part of
the arguments and arguments in the stdcall line for the remaining arguments.
This can be very convenient in some cases. For example see the following source:
;begin
    stdcall CreateSomeObject
    push    eax
    stdcall DoSomething
    stdcall DeleteSomeObject
;end
Here, the procedure DoSomething changes the value of eax, so the handle is saved
in the stack. The procedure DeleteSomeObject needs one argument — a handle of
the object. But as long as the proper value is already in the stack, it is
mindless to pop the value and then to push it again. So the source calls
DeleteSomeObject without any arguments. The procedure knows the proper number
of arguments (one in this example) and clean the stack properly.

The standard (and wrong) approach is to pop the argument from the stack and then
to pass it to the procedure explicitly is the stdcall statement:
;begin
    stdcall  CreateSomeObject
    push     eax                ; save the handle.
    stdcall  DoSomething
    pop      eax                ; ??? Why ???
    stdcall  DeleteSomeObject, eax
;end
This source will generate the meaningless instructions sequence:
;begin
    pop      eax
    push     eax
;end
*invoke* macro is the same as "stdcall" with the only difference - it calls the procedure
indirectly ( `call [proc]` instead of `call proc` ).  This mechanism usualy is used to call
the functions imported from external dynamic linked libraries.
Of course, the imported functions can be call with `stdcall [someproc]` but the *invoke*
macro helps to better distinguish what procedures are imported and what are internal for the
program.

*NOTE:* The user should never use *invoke* in the portable programs, because such programs
never use directly OS dependent import functions.


*ccall* macro calls a procedure with CCALL convention. This means that the procedure returns
with simple "retn", without cleaning the parameters from the stack. Then "ccall" macro provides
instructions that remove the arguments from the stack.

Because ccall have to know the exact count of passed arguments, all arguments have to be passed
explicitly as a values in the ccall statement.
Tricks as described above will not work properly and leads to stack not properly cleaned after
the call.

"cinvoke" is the same as ccall, but using indirect call. The reason for existing of "cinvoke"
macro is the same as with "invoke" macro — better legibility of the source.

*The parameters passed to all these procedure calls can be several types:*
 
* 32 bit valid `push` instruction operand - it is pushed directly.

* String up to 4 bytes long - it is also pushed directly, as a 32 bit integer number in accordance with FASM syntax.

* String, longer than 4 bytes - unnamed string constant is created in the memory and the address of this string is 
pushed in the stack. The equal string constants are created only once and the same address is reused on every call.
See [#text] macro for details.


*About the calling conventions:* While all Win32 dynamic linked libraries uses STDCALL
convention, most (if not all) of Linux libraries uses CCALL convention.

*All code libraries of Fresh use STDCALL calling convention and it is platform independient.*

-------------------------------------------------------------------------------------

### "_globals.inc" library 

This library defines several macros intended to deal with data definitions.

Usually all data definitions have to be placed in special section of the
executable file. ([#_DataSection] in FreshLib). This is not very convenient, because the code
that process this data and the data definitions must reside in separate places of the source
code, and in most cases even in different files.

The idea of *"globals.inc"* macro library is to allow the data definition to be
described anywhere in the source code, but these definitions to be defined at
once, at the place the programmer wants - usually in the data section of the
program.

--------------------

[#uglobal] `macro uglobal`
[#iglobal] `macro iglobal`
[#endg] `macro endg`
[#IncludeAllGlobals] `macro IncludeAllGlobals`

*uglobal* begins block for undefined data definition. The block ends with *endg*
macro. Between "uglobal" and "endg" macro any count of data definitions can be
inserted.

Note that because uglobal block defines undefined data, it is only the labels
and the size of data that have meaning inside this block. Any data, defined with
data definition directive will not increase the size of the executable file, but will
be allocated when the executable is loaded in the memory.

The undefined data will be defined later at the place where "IncludeAllGlobals"
macro resides. In order to not increase the size of the executable file,
the undefined data is always placed at the end of all data definitions.

"iglobal" macro, again combined with "endg" defines initialized data. The data
defined in the block will be created at "IncludeAllGlobals" statement.

This block increases the size of the executable file, because it contains
sensible data, that have to be included in the file.

Actually, neither *uglobal*, nor *iglobal* blocks defines any data immediately.
Instead, the data definitions are stored in a list. The real definition occurs
later, when *IncludeAllGlobals* macro is invoked.

For this reason, *IncludeAllGlobals* must be placed in the source after all used
global data blocks.

*Notice*: Usually *IncludeAllGlobals* is automatically invoked at the end of the source, in accordance with
  [#@BinaryType] format set in the beginning of the program. The programmer should not use it if the `model` argument
is set to `default`, `compact` or is missing. But if the `model` is set to `manual`, the
programmer must to use `IncludeAllGlobals` explicitly somewhere in the source.

---------------------

[#text] `struc text [val]`

The macro *"text"* is actually a structure. It needs to be preceded by some label name.

This macro accepts string or number arguments. When it is invoked with string arguments,
it defines a zero terminated string constant, and also a local constant *.length*
equal to the length of the string without terminating zero. When invoked with number as argument,
*"text"* defines label at the address *val* and does not defines .length constant.

The *"text"* macro, the same way as *iglobal* and *uglobal*, simply stores string data for
defer definition. This definition, occurs in IncludeAllGlobals invocation.
Note that the real definition will be made only if the string is used in the program.
Not used strings will not be defined.

Look at the following example:
;begin
        myName text 'John',$20,'Smith'
;end
This code will define the data and constant labels following way:
;begin
        if used myName
          myName db 'John Smith'
          .length = $-myName
                 db 0
        end if
;end

Why to define separate macro for the strings and not to use the normal iglobal
block? 

At first, *text* macro defines a real data only if this data is used
somewhere in the source. This way is prevented bloating of the code with
unneeded data definitions.

At second, the *text* macro defines every string only once. If some other string is 
defined with the same content, then the string is defined only once and the second
label gets the address of the already defined string.

This approach allows using of unnamed string constants in the procedure calls arguments
without allowing duplicated data definitions. See for details [#stdcall].

------------------

[#var] `macro var expr`

The macro *var* defines dword variable with a given value. The use is following:
;begin
        var MyVar = 1234
;end
The only differens from the usual use of *dd* directive is that the variable will be
defined only if used in the source.

Note that the variable is created at the place where *var* is used, so you need to place it
inside a *iglobal* block if you want it to be defined in the global data place.

---------------------

### "_struct.inc" library 

This library contains only two simple macros:

[#struct] `macro struct name`
[#ends] `ends`

*struct* macro is aimed to provide easy creation of data structures. The "struc"
directive in FASM is known to not create actual labels, but only the template
for the label definitions. So, we need to create an instance of the data
structure in order to have addresses and offsets of its fields.

But very often we don't have static data structure of the given type, but data
structure, pointed by some of the registers. In this case in order to use
offsets to the fields of the data structure, we need to define at least one
virtual instance of the structure at address 0. Then we can use the values of
the fields as an offsets in the instructions - for example:
;begin
    mov eax, [esi+RECT.right].
;end
So, this is exactly what "struct" macro does. Besides it defines the "struc"
structure with the given fields, it creates a single virtual instance of this
structure, in order to be used later for register addressing.
Also, the macro defines local constant of *sizeof.* global label equal to the
byte size of the structure.
In all remaining functionality it behaves exactly as the struc directive.

The syntax of struct macro is the following:
;begin
    struct StructureName
      .field1 dd ?
      .field2 RECT
      .fieldN:
    ends
;end
The definition begins with "struct" followed by the structure name.
The definition ends with "ends" directive. Between both, any local label
definition becomes a member of the structure.
The above definition, results in following code:
;begin
    struc StructureName {
      .field1 dd ?
      .field2 RECT
      .fieldN:
    }
    virtual at 0
      StructureName StructureName
      sizeof.StructureName = $
    end virtual
;end

--------------------------------------------------------------

### "_display.inc" library 

This library contains macros that enhance the functionality of standard FASM
"display" directive.


[#disp] `macro disp [arg]`

The macro "disp" displays the strings given in the arguments, just as "display"
FASM directive does. Additionally it can display numbers in any given radix:
;begin
    disp <number, radix>
;end

---------------

[#DispSize] `macro DispSize Text, Sz`

"DispSize" is very specialized macro, that displays the text and number in
the following form:
;begin
Size of [Text] is: Sz bytes
;end
The size number is automatically scaled to bytes or kbytes, depending on the
value of Sz.

This macro allows easy display and control of the sizes of particular areas of
the program - data structures, subroutines etc.

DispSize macro behavior is controlled by [#options.ShowSizes] option.

-----------------

[#display] How Fresh implements "display" directive

There are some specifics in Fresh, concerning message displaying. The "display"
directive in Fresh works in a slightly different way than the original FASM directive.

It outputs text in Fresh message window. Each message can have one of six icons,
or it can have no icon at all. And because message window is implemented as a
TreeView control, you can organize your messages into groups (directories).

Implementation is a bit "tricky" - when you display a character whose code is
less than 16, it is interpreted in a special way. Characters from 1 to 6 set an
icon of current message. It sounds complicated, but it is quite simple. Try:
;begin
    display 2, "some message"
;end
It will display "some message" with an error icon. Another codes are used for
controlling directory structure. Try to type following lines and see what would
happen:
;begin
    display 3, "message at root", 0x09
    display 3, "child message1", 0x0a
    display 3, "child message2", 0x0d
    display 3, "again at root", 0x0a
;end
Of course you don't have to put each message in separate display directive, you
can, with the same result write:

display 3, "at root",$09,3,"child1",$0a,3,"child2", $0d,3,"again at root",$0a

Here is the complete list of all special characters and their meanings:
;table
char

meaning

note
;-------------
$01

set current icon to "warning"

 [?_images/warning.gif]
;------------------
$02

set current icon to "error"

 [?_images/error.gif]
;-----------------
$03

set current icon to "info"

 [?_images/information.gif]
;----------------
$04

set current icon to "find"

 [?_images/find.gif]
;----------------
$05

set current icon to "none"

--
;----------------
$06

set current icon to "debug" 

 [?_images/debug.gif]
;----------------
$08 

end current row and set one level back.

--
;----------------
$09

end current row and set it as new directory.

--
;----------------
$0a

end current row and keep current level.

--
;----------------
$0d

end current row and set current level to root level.

--
;end


;;begin
;;+------+--------------------------------------------------------+
;;| char |   meaning                                              |
;;|:----:|:-------------------------------------------------------|
;;| $01  |   set current icon to "warning"                        |
;;| $02  |   set current icon to "error"                          |
;;| $03  |   set current icon to "info"                           |
;;| $04  |   set current icon to "find"                           |
;;| $05  |   set current icon to "none"                           |
;;| $06  |   set current icon to "debug"                          |
;;| $08  |   end current row and set one level back.              |
;;| $09  |   end current row and set it as new directory.         |
;;| $0a  |   end current row and keep current level               |
;;| $0d  |   end current row and set current level to root level  |
;;+------+--------------------------------------------------------+
;;          display directive special characters
;;end


-------------------


## FreshLib directory "system/" 


-----------------


### "memory.asm" library 

This library provides OS independent way of allocating, reallocating and freeing
dynamic memory blocks.
All other libraries in FreshLib that needs dynamic memory, use this library.

The user who needs such memory blocks should use it as well.

--------------

[#GetMem] `proc GetMem, .size`

Allocates `[.size]` byte of dynamic memory.

Returns:

 `CF=0`; EAX = pointer to the allocated memory;

 `CF=1`; EAX=0 if the memory can not be allocated.

The memory is filled with NULL.

------------------

[#FreeMem] `proc FreeMem, .ptr`

Frees the specified in `[.ptr]` dynamically allocated memory.
Returns nothing.

-------------------

[#ResizeMem] `proc ResizeMem, .ptr, .newsize`

Reallocates memory on address `[.ptr]` to the new size in `[.newsize]`

Returns:

CF=0; EAX = pointer to the allocated memory;

CF=1; EAX=`[.ptr]` if the memory can not be reallocated.
In this case, the memory block is not changed

The increased part of the memory block is not zeroed.

-----------------


### "files.asm" library 


[#FileOpen] `proc FileOpen, .filename`

The procedure opens the file with filename in `[.filename]` for reading.

Returns:

`CF=0`; EAX = Handle to the file.

`CF=1`; EAX = Error code.

-------------------

[#FileCreate] `proc FileCreate, .filename`

Creates a file or opens the existing one and truncates its size to 0. The file is opened for writing.

Returns:

`CF=0`; EAX = Handle to the file.

`CF=1`; EAX = Error code.


----------------------

[#FileClose] `proc FileClose, .handle`

Closes the previously opened file.

Returns:

`CF=0`; EAX = Handle to the file.
`CF=1`; EAX = Error code.

----------------------

[#FileRead] `proc FileRead, .handle, .buffer, .count`

Reads `[.count]` bytes from the file `[.handle]` in the buffer at `[.buffer]`.

Returns:

`CF=0`; EAX = The count of actually read bytes.
`CF=1`; EAX = Error code.

---------------------

[#FileWrite] `proc FileWrite, .handle, .buffer, .count`

Writes `[.count]` bytes from the buffer `[.buffer]` to the file with handle `[.handle]`.

Returns:

`CF=0`; EAX = The count of actually written bytes.

`CF=1`; EAX = Error code.

------------------------

[#FileSeek] `proc FileSeek, .handle, .dist, .direction`

Moves the file pointer of the file `[.handle]` on `[.dist]` distance (in bytes) relative to `[.direction]`.

Direction is one of the following values:

`fsFromBegin` — relative to the file begin.

`fsFromEnd` — relative to the file end (then `[.dist]` should be negative).

`fsFromCurrent` — relative to the current position.

[#FileDelete] `proc FileDelete, .filename`

Deletes the file with filename in `[.filename]`

Returns:

`CF=0`; The file was deleted.
`CF=1`; EAX = Error code.

--------------------------

[#GetErrorString] `proc GetErrorString, .code`

Returns in EAX, pointer to the human readable error message, corresponding to the error code
passed in `[.code]`

The message string have to be passed to FreeErrorString, when not needed.

---------------------------

[#FreeErrorString] `proc FreeErrorString, .ptrString`

Frees the error string `[.ptrString]`, previously returned by GetErrorString. As long as the
error strings are allocated by the OS, they have to be free by OS as well.
Returns nothing.

--------------------------

[#LoadBinaryFile] `proc LoadBinaryFile, .ptrFileName`

Loads the whole file `[.ptrFileName]` to the dynamically allocated memory block.

Returns:

`CF=0`; EAX = pointer to the allocated memory; ECX = the size of the loaded file.

`CF=1`; EAX = Error code. ECX = 0; The memory is not allocated.

The allocated memory have to be free after use with [#FreeMem].

---------------------------

[#SaveBinaryFile] `proc SaveBinaryFile, .ptrFileName, .aptr, .size`

Creates or overwrites the file `[.ptrFileName]` with the `[.size]` bytes from the buffer `[.aptr]`;

Returns:

`CF=0`; EAX = count of the bytes actually write;
`CF=1`; EAX = error code;

--------------------------

[#FileExists] `proc FileExists, .ptrFileName`

Check the existence of the file with name in `[.ptrFileName]`.

Returnds:

`CF=1` — the file *does not* exists.
`CF=0` — the file exists.

The existence of the file is checked using [#FileOpen] procedure.
If the file can be opened, it is considered existing.

-----------------

### "process.asm" library 


[#Terminate] `proc Terminate, .exit_code`

Terminates the application and all of its threads.
Returns `[.exit_code]` to the OS.

This procedure simply does not returns, because the application stops.

----------------------

[#ThreadCreate] `proc ThreadCreate, .ptr_to_function, .ptr_to_args`

Creates new thread. `[.ptr_to_function]` points to the thread procedure.
The thread procedure should have one argument.
When the thread starts, `[.ptr_to_args]` is passed as a thread argument.

Returns:

`CF=0`; EAX = is a handle to the new thread. In the different OSes this value can have different meaning.
But it identifies the thread anyway.

`CF=1`; EAX = error code;

------------------------

[#MutexCreate] `proc MutexCreate, .ptrName, .ptrMutex`

Creates new mutex with name `[.ptrName]` and save its handle to `[.ptrMutex]` variable.

The calling thread takes the owneship of the mutex.

If `[.ptrName]` = 0, unnamed mutex will be created.

------------------------

[#WaitForMutex] `proc WaitForMutex, .ptrMutex, .timeout`

Waits until the mutex is released and takes the ownership.

Returns:

`CF=0` — the mutex ownership is successfuly obtained.
`CF=1` — the timeout was expired.


[#MutexRelease] `proc MutexRelease, .ptrMutex`

Releases the ownership of the specified mutex.

-----------------------

[#MutexDestroy] proc MutexDestroy, .ptrMutex

Destroys the mutex `[.ptrMutex]`

-----------------

### "clipboard.asm" library 

[#clipboard.asm] clipboard.asm library contains very simple clipboard functions that 
works only on text data.

------------------

[#ClipboardRead] `proc ClipboardRead`

Returns in EAX handle to the string with the current clipboard content.
If the clipboard is empty or contains not textual information, EAX=0;
The user should delete the string when not needed by passing it to [#StrDel].

--------------------

[#ClipboardWrite] `proc ClipboardWrite, .hstring`

Writes the string `[.hstring]` to the clipboard.
Returns nothing.

-----------------

## FreshLib directory "timers/" 


### "timers.asm" library 

[#timers.asm] library deals with user created timers and also contains some 
procedures for work with the system time and date.

------------------------------------

[#TTimer] `TTimer` structure.

The timers in FreshLib are represented with the following memory structure:
;begin
    struct TTimer
      .next dd ?

      .interval dd ?
      .value    dd ?


      .flags    dd ?
      .Callback dd ?
      .Expired  dd ?
      .tag      dd ?
    ends
;end
The fields are:

  * `.next` —  Don't change this. It is a pointer to the next timer in the timers chain. It is for internal use only.

  * `.interval` — the interval of the time in ms

  * `.value` — The current value of the timer in ms. When this value becomes higher than `[.interval]` an event is 
fired and the value becomes 0. This value is incremented by the system dependent time step - probably something like 1..100ms

  * `.flags` — contains a set of tmfXXXX flag values. Determines the behavior of the timer. See below for description of the flags.

  * `.Callback` — pointer to the callback procedure of the timer.
                  The callback procedure should accept one argument with the pointer to the timer that fired the event: `proc OnTimer, .ptrTimer`

  * `.Expired`  —  count of the timer expirations, if the callback procedure was not called.

  * `.tag`  —  user defined value associated with the timer.


The `.flags` field can have one or more of the following values:

 * `tmfDoNothing`  — when the timer expires no action should be performed. .Expired field of the timer will be incremented.

 * `tmfCallProc` —   `[TTimer.Callback]` contains pointer to the procedure that to be executed once per timer expiration.

 * `tmfSyncDestroy` — If this flag is set, the timer will be destroyed on the next timer expiration.
                      In this case, the configured event is fired and then the timer is destroyed.
                      The flag is checked after the event returns, so the event handler can reset this flag and thus to prevent destruction.

 * `tmfRunning` — If this flag is set, the timer runs. If the event handler resets this flag, the timer will fire only once and will be suspended.

-----------------------

[#TimerCreate] `proc TimerCreate`

Creates a new timer.

Returns:

 * CF=0; EAX= pointer to the TTimer structure. The timer is created suspended.
         The user can set or reset tmfRunning in `[.flags]` in order to start or stop the timer.
         Also, the user have to enter proper values in the remaining fields.

 * CF=1; Error allocating memory.

---------------------- 

[#TimerDestroy] `proc TimerDestroy, .ptrTimer`

Destroys the timer `[.ptrTimer]`

------------------


## FreshLib directory "simpledebug/"

### "debug.asm" library 

[#simpledebug] This library includes number or macros and procedures aimed to assist the debugging
process of the application. These macros display different data values on the debugging
console.

The library contains its own output procedures, so it does not depend on the other used libraries.

All the macros from this library generate code only when [#options.DebugMode] = 1, so the
programmer can include as many debug statements as needed and leave them in the source.
They will not be included in the final binary.
The debug macros will always preserve all registers, except the EFLAGS register.

-------------

[#DebugMsg] `macro DebugMsg msg`

Displays the text message `msg` to the debug console.
Example:
;begin
     DebugMsg 'The program executes here!'
;end

----------------

[#OutputRegister] `macro OutputRegister reg, radix`

Outputs the content of some register in the given radix. Example:
;begin
    OutputRegister regEAX, 10
;end
The possible register values are: `regEDI`, `regESI`, `regEBP`, `regESP`, `regEBX`, `regEDX`, `regECX`, `regEAX`

----------------

[#OutputMemory] `macro OutputMemory pointer, size`

OutputMemory will dump `[size]` bytes of memory at address `[pointer]`; Example:
;begin
    OutputMemory esi, 128
;end

---------------

[#OutputNumber] `macro OutputNumber number, radix, digits`

Outputs *digits* digits of the *number* in *radix* radix. Example:
;begin
    OutputNumber 12345, 16, 8
;end

------------------

[#GetTimestamp] `proc GetTimestamp`

Returns in eax timestamp measured in milliseconds (ms).

-----------------


## FreshLib directory "data/" 

This directory contains several libraries that handles different data structures.
The libraries are mostly OS independent.
Actually the only OS dependent part is one small routine in Win32 section, that
converts strings from UTF-8 to UTF-16 because Windows can't handle UTF-8 strings
directly.

------------------

### "arrays.asm" library 

This library handles dynamic arrays, containing elements of arbitrary size.
All elements of the array have the same size.

[#TArray] TArray structure have following definition:
;begin
    struct TArray
      .count     dd ?
      .capacity  dd ?
      .itemsize  dd ?
      .lparam    dd ?
      label .array dword
    ends
;end
The above structure represents the header of the array. The actual array will
have arbitrary size, depending on the element count and size.

The first element of the array begins on offset *TArray.array* from the begining
of the memory block.

The field *TArray.count* contains the current element count of the array.

The field *TArray.capacity* contains the current capacity of the array.
It is because the library usually allocates more memory than is needed for the array
element count.
This approach reduces memory allocations and reallocations and
thus increases the speed of inserting and deleting elements in the array.
How many memory will be allocated depends on the user setting of the variable
ResizeIt (defined in memory.asm). This variable contains a pointer to the
procedure that simply increases the value of ECX to the next suitable value.

The field *TArray.itemsize* contains the size in bytes of one array element.
Changing of this value is not recommended.

The field *TArray.lparam* is for user defined parameter, associated with the array.

-----------------------------

[#CreateArray] `proc CreateArray, .itemSize`

This procedure creates new array with item size `[.ItemSize]`

The procedure returns CF=0 if the array is properly created and pointer to the
array is placed in EAX.

In case the memory cannot be allocated, the procedure returns CF=1.
To free the allocated array, use [#FreeMem] procedure.

------------------------------

[#AddArrayItems] `proc AddArrayItems, .ptrArray, .count`

This procedure adds new array items at the end of the array pointed by `[.ptrArray]`

The procedure returns two values:

EAX contains pointer to the first of the new appended elements.

EDX contains pointer to the array (in the process of appending of the new
element, it is possible the whole array to be moved to the new address in
memory, so the programmer should store the value of EDX for the future
reference to the array.

In case, the new memory can not be allocated, the procedure returns CF=1 and
EDX contains the proper pointer to the original array.

----------------------------------

[#InsertArrayItems] `proc InsertArrayItems, .ptrArray, .iElement, .count`

This procedure inserts `[.count]` new elements at the `[.iElement]` position of the
array pointed by `[.ptrArray]`

If `[.iElement]` is larger or equal to `[TArray.count]` the elements are appended
at the end of the array. (Just like AddArrayItems) Otherwise, all elements are
moved to make room for the new elements.

The procedure returns exactly the same results as AddArrayItems procedure — EDX
points to the array and EAX points to the first of the new inserted elements.

CF is an error flag.

---------------------------------

[#GetArrayItem] `proc GetArrayItem, .array, .item`

CF=0; Returns in EAX pointer to the array item with index `[.item]`.

CF=1; The requested item does not exists ( `[.item]` >= `[.array.count]` ). In this case,
EAX contains pointer to the end of the array the byte next after the last array element.

---------------------------------

[#DeleteArrayItems] `proc DeleteArrayItems, .ptrArray, .iElement, .count`

This procedure deletes `[.count]` items with begin index `[.iElement]` the `[.ptrArray]`
dynamic array. If the capacity of the array is bigger than the recommended for
the new count, then the array is resized. The recommended size is calculated
using ResizeIt procedure from memory library.

Returns EDX - pointer to the TArray. In the most cases this pointer will not be
changed, but this also depends on the current OS memory allocation API, so it
is safer to store the pointer for future use, instead of one passed to the
procedure.

This procedure can not fail, because deleting element is always possible. In
some rare cases it can fail to reallocate smaller memory block, but this is
not a problem for the array consistency.

---------------------------

[#VacuumArray] `proc VacuumArray, .ptrArray`

This procedure removes the reserved memory from the array in order to make it
as small as possible.
Note, that the first insert/append operation after the vacuum operation will be very slow.
The memory economized this way depends on reallocation strategy and can be from 25 to 100% in some cases.

--------------------------

[#ListIndexOf] `proc ListIndexOf, .ptrList, .Item`

The list is a special case of array with item size equal to 4 bytes (dword).
This procedure searches the list `[.ptrList]` for item equal to `[.Item]` and
returns the index of the element in EAX. In case of error CF=1.

---------------------------

[#ListFree] `proc ListFree, .ptrList, .FreeProc`

Frees all elements of the list `[.ptrList]`, calling `[.FreeProc]` for every
element of the list.

FreeProc callback procedure have one argument of type dword that is the value
of the current list element. The definition of the callback procedure is similar
to following:

;begin
    proc FreeMyListItem, .ptrItem
    begin
            ;do something with the item being freed
            return
    endp
;end


-----------------


### "strlib.asm" library 

[#StrLib]

Using strings in assembler was often problematic for programmers - static
strings can't be resized, so they had to reserve as many bytes as they thought
user could need, and it still could be not enough. For that reason we created
Dynamic String Library - a library that operates on dynamic strings, that are
automatically resized when needed. Also, StrLib contains many functions that
perform different string operations — comparison, inserting one string into
another, etc.
In StrLib, the strings are represented by handles, not by pointers. This way,
the string can be freely resized and moved in memory.
StrLib can distinguish the handle values from pointer and will process properly
both of them. When the processing is possible, the procedures will operate
on static strings in memory.

[#StrLib string format]

The strings in the StrLib are stored in specific format. The format is defined
following way:
;begin
    struc string {
      .capacity dd ?
      .len      dd ?
      label .data byte
    }

    virtual at -(sizeof.string)
      string string
      sizeof.string = $-string
    end virtual
;end
The structure string have variable length and is dynamically allocated.

The field *string.capacity* on offset `-8` contains the allocated memory size in bytes.

The field *string.len* on offset `-4` contains the current length of the string in bytes.

The string content begins on offset 0. The content of the string always ends with at least one
zero byte, so the string format is compatible with ASCIIZ format used in the most OS API.

All procedures in StrLib will set `[string.len]` to the proper value and will use it in the
string processing.

If the programmer manipulates the string data directly, he should set `[string.len]` himself, or
call [#StrFixLen] in order to let StrLib to scan the string and to fix the length field.


[#StrLib procedures]

StrLib procedure reference:

[#StrNew]
;begin
        proc StrNew
;end
Creates new dynamic string and returns its handle.

[#StrDel]
;begin
        proc StrDel, .hstring
;end
Frees the memory occupied by given string. If the .hstring is pointer to memory, StrDel
will try to find it in the table of created strings and if found, will free it as well.
If the string passed by pointer is not found in the list - StrDel exits without error.
Note, that passing pointer can degrade the performance of the procedure.

[#StrPtr]
;begin
        proc StrPtr, .hstring
;end
Returns in EAX the pointer of the string with handle `[.hstring]`
If .hstring is pointer EAX will be equal to `[.hstring]`
If the handle is invalid, StrPtr returns CF=1 and EAX=0.


[#StrLen]
;begin
        proc StrLen, .hstring
;end
Returns the length of the string in bytes, excluding the terminating zero.
If `[.hstring]` is handle, the procedure returns directly the stored length of the string.
If `[.hstring]` is pointer, the functions scans the string and computes the length.
Thus, passing handle is much faster, especially for long strings.


[#StrDup]
;begin
        proc StrDup, .hstring
;end
Creates new string and copy the content of `[.hstring]` to it.
Returns in EAX — handle of the new string.
`[.hstring]` can be memory pointer or string handle.



[#StrFixLen]
;begin
        proc StrFixLen, .hstring
;end
StrFixLen scans the string in order to compute its actual length and then writes this length
in the field `[string.len]`.
StrFixLen should be call only with handle of the string as argument. It will process pointer as
well, but will assume there is a field `[string.len]` at offset `-4`.
The user should call StrFixLen only if the `[string.len]` field does not contains the proper value,
because of some reason - for example the user made some string processing that changes the length
of the string or the string data is returned by some OS function that does not care about string
length.


[#StrSetCapacity]
;begin
        proc StrSetCapacity, .hString, .capacity
;end
This function ensures that the allocated for the string memory is enough to hold at least
`[.capacity]` bytes. If needed the string memory is reallocated.
Returns pointer to the string data in EAX.
If the reallocation is impossible, returns CF=1;


[#StrCopy]
;begin
    proc StrCopy, .dest, .source
;end

Copies the content of `[.source]` string to `[.dest]` string.
`[.dest]` must be a handle.
`[.source]` can be handle or pointer.
Returns nothing.



[#StrCompCase]
[#StrCompNoCase]
;begin
    proc StrCompCase, .str1, .str2
    proc StrCompNoCase, .str1, .str2
;end
Compares two strings - case sensitive (StrCompCase) or string not sensitive (StrCompNoCase).

Returns CF = 1 if the strings are equal.

Returns CF = 0 if the strings are different.

The speed of this procedure varies depending on passed strings and its content.
The worst case is when the strings are passed as pointers and have equal lengths.
The best case is when the strings are passed as handles and have different lengths.


[#StrCat]
;begin
    proc StrCat, .dest, .source
;end
Concatenates the string `[.source]` to the end of the string `[.dest]`.

[#StrCharPos]
;begin
    proc StrCharPos, .hString, .char
;end
StrCharPos returns a pointer to the first occurence of a given char in specified string.

[#StrPos]
;begin
    proc StrPos, .hstring, .hpattern
;end
StrPos returns in EAX a pointer to the first occurence of a `[.hpattern]` string in
`[.hstring]` or NULL if the pattern was not found.


[#StrCopyPart]
;begin
    proc StrCopyPart, .dest, .source, .pos, .len
;end
Extracts `[.len]` bytes on position `[.pos]` from the string `[.source]` and copies them
to the string `[.dest]`.
Returns CF=1 if the needed memory can not be allocated.


[#StrExtract]
;begin
    proc StrExtract, .string, .pos, .len
;end
Extracts `[.len]` bytes on position `[.pos]` from the string `[.source]` and copies them
to the new created string.
Returns the created string in EAX or CF=1 if the needed memory can not be allocated.


[#StrSplit]
;begin
    proc StrSplit, .hString, .pos
;end
Splits the string `[.hstring]` into two parts on byte possition `[.pos]`.
The left part remains in `[.hstring]`; The right part is returned as new created string in EAX.
Note that the memory of the `[.hstring]` will not be reallocated, only the length of the string
will be set accordingly.


[#StrInsert]
;begin
    proc StrInsert, .dest, .source, .pos
;end
Inserts the `[.source]` string on possition `[.pos]` into the `[.dest]` string.
Returns nothing.


[#NumToStr]
;begin
    proc NumToStr, .num, .flags
;end
Converts number `[.num]` in any radix to string.
Returns the new created string in EAX.

`[.flags]` controls the way number have to be converted.
.flags is dword value that contains following values:

byte0 - number of digits if ntsFixedWidth is specified.

byte1 - radix for the convertion. Some radixes have predefined constants:
;begin
    ntsBin  = $0200
    ntsQuad = $0400
    ntsOct  = $0800
    ntsDec  = $0a00
    ntsHex  = $1000
;end

byte2, byte3 - flags:
;begin
    ntsSigned       = $00000
    ntsUnsigned     = $10000
    ntsFixedWidth   = $20000
;end

[#StrToNumEx]
;begin
    proc StrToNumEx, .hstring
;end
Converts `[.hstring]` to number.
Returns CF=0 and value in EAX if the conversion was successful, or
CF=1 and EAX = 0 if not.

The procedure supports the FASM numbers format:

`0x1111`, `$1111` or `1111h` will be converted as HEX;

`1111` as decimal;

`1111b` as binary;

`1111o` as octal.


[#StrCharCat]
;begin
    proc StrCharCat, .hString, .char
;end
Appends up to 4 bytes fro `[.char]` at the end of `[.hString]`


[#StrCharInsert]
;begin
    proc StrCharInsert, .hString, .char, .pos
;end
Inserts up to 4 characters from `[.char]` into the `[.pos]` position of the `[.hString]`


[#StrClipSpacesR]
[#StrClipSpacesL]

;begin
    proc StrClipSpacesR, .hString
    proc StrClipSpacesL, .hString
;end

Removes the spaces from the start (StrClipSpacesL) or from the end (StrClipSpacesR)
of the string `[.hString]`.


[#StrCleanDupSpaces]
;begin
    proc StrCleanDupSpaces, .hString
;end
Removes duplicating spaces from the string `[.hStrin]` and leaves only single spaces.
For example the string ("." represents the space char) "123.....456" will be processed to "123.456".

[#StrHash]
;begin
    proc StrHash, .hString
;end
Computes the hash value from the string `[.hString]`.
This procedure implements FNV-1b algorithm.

Returns 32 bit hash value in EAX.


[#DataHash]
;begin
    proc DataHash, .ptrData, .len
;end
Computes the hash value from the memory array at address `[.ptrData]` with byte length `[.len]`.
This procedure also uses FNV-1b algorithm.

Returns 32 bit hash value in EAX.


[#StrLenUtf8]
;begin
    proc StrLenUtf8, .hString, .len
;end
Computes the length in chars of the first `[.len]` bytes of the UTF-8 encoded string `[.hString]`
The scan of the string ends on one of the two conditions — terminating zero byte
is reached or `[.len]` bytes are processed. So, if `[.len] == -1` the scan will always end on the
end of the string.


[#StrOffsUtf8]
;begin
    proc StrOffsUtf8, .hString, .pos
;end
Returns in EAX the address of the `[.pos]` character of the UTF-8 encoded string `[.hString]`
If the length of the string is less than `[.pos]` — returns NULL.


[#DecodeUtf8]
;begin
    proc DecodeUtf8, .chars
;end
Decodes 4 bytes in `[.chars]` to UNICODE dword value.

Returns:
`CF=0` — no error; eax — unicode value; edx — byte count of the char. `[1..4]`

`CF=1` — invalid utf-8 char; if eax = edx = 0;  the character can not be decoded;
if edx <> 0 — eax = the overlong encoded character. edx = byte count of the char.

*Note:* When CF=1 and `[.chars]` is overlong encoded char, eax contains the proper
value and edx contains the proper length. But it is still invalid character, according
to the standards.

[#ExpandTabs]
;begin
    proc ExpandTabs, .hstring, .tabstop
;end

Converts the tab characters in `[.hstring]` into space characters, according to `[.tabstop]` length.
Returns in EAX a value, that indicates by how many chars the length of the string increased.


-----------------


### "uConfig.asm" library 

uCongig library is implementation of small [hierarchical] database engine, intended to keep program settings and
preferences in OS independent manner.
The data in the uConfig database have tree structure similar to the file system directory structure
or to Windows registry structure.
Every record or directory in the database has its own key — dword value.
Usually it is convenient to use as a key 4 char ASCII string in order to be human readable, but
it is not mandatory.
;quote
The uConfig format is not "human readable", "universal", "super-puper", etc.
It was designed with only two aims:

1. Small and simple engine, suitable to be used from assembly.

2. Relatively robust database format.

So, if someone wants some new advanced features - these features should make the engine
smaller or at least to keep its current size.
;end

[hierarchical] http://en.wikipedia.org/wiki/Hierarchical_database_model

The database have two representations — packed "file representation" and
expanded "memory representation".
Database operations can be provided only on expanded form.

The base of the database is TConfigRecord structure. The database itself is an array of
TConfigRecords.

[#TConfigRecord]
;begin
    struct TConfigRecord
      .KeyName  dd ?
      .DataSize dd ?
      .Type     dd ?
      .Data     dd ?
    ends
;end
The fields have following meaning:

* .KeyName — contains the key of the record.

* .DataSize — the size of the data in bytes if .Data field contains pointer to the data.

* .Type is one of the following values:
;quote
*  cdtNULL     = 0
*  cdtInteger  = 1  — .Data contains the number.
*  cdtString   = 2  — .Data contains string handle (see [#StrLib])
*  cdtBlob     = 3  — .Data contains pointer to the blob data. .DataSize — its size
*  cdtConfig   = 4  — .Data contains pointer to the [#TArray] of TConfigRecords — i.e. uConfig database.
;end
* .Data — data value if fits in dword or pointer to the data for the bigger formats.

There are number of procedures intended to provide manipulation of uConfig database:

[#LoadCongigDB]
;begin
    proc LoadConfigDB, .ptrSource, .signature
;end
Loads the "file representation" of database and expands it to "memory representation".
".signature" is DWORD value, that identifies the database. The signature is actually 8 bytes long —
the first dword identify the file as a uConfig database and the second dword are user defined.

The procedure returns:

CF=0; EAX = pointer to the root level of the expanded database

CF=1; Database error:
;quote
EAX = `-1` : Bad signature

EAX = `-2` : Damaged database. Some control sum is wrong.
;end


[#SaveConfigFile]
;begin
    proc SaveConfigFile, .ptrRoot, .signature
;end
Creates "file representation" of the database as a memory TArray of dword. The user have to save
this image to the file if needed.

* .ptrRoot is pointer to TArray ot TConfigRecord.

* .signature if the desired signature for the database file.

The procedure returns pointer to TArray. The user should free it later.


[#FreeConfigDB]
;begin
    proc FreeConfigDB, .ptrRoot
;end
Frees the uConfig database and all its records.

[#GetConfigParam]
;begin
    proc GetConfigParam, .ptrConfig, .pDirectory, .name
;end
Search the database `[.ptrConfig]` for the record with keyname `[.name]`

Returns EAX = poiner to the TConfigRecord or NULL if the record is missing.

`[.pDirectory]` should point to the zero terminated array of dwords with the path to the directory
of the needed record. `[.pDirectory]` can be NULL.

[#GetConfigParam.AsString]
;begin
    proc GetConfigParam.AsString, .ptrConfig, .pDirectory, .name
;end
Returns handle to string with textual representation of the value of the database record.
The user have to free this string later with [#StrDel].
This procedure is intended to be use for screen display of the values of the database.
Depending on the type of the field it returns:

 *  cdtNULL — "NULL"

 *  cdtInteger  — The number converted to decimal string.

 *  cdtString   — A copy of the string.

 *  cdtBlob — "BLOB"

 *  cdtConfig  — "SDIR"


[#DelConfigParam]
;begin
    proc DelConfigParam, .ptrVarConfig, .pDirectory, .name
;end
Deletes the specified config record. Returns nothing.



[#SetConfigParam]
;begin
    proc SetConfigParam, .ptrVarConfig, .pDirectory, .name, .type, .value, .size
;end
Set the value of the given config record. If the record exists, the value will be changed.
If the record with the given name does not exists, it will be created.
Returns error in CF. If CF=1 the specified directory does not exists.



-----------------


### "memstream.asm" library 


-----------------


## FreshLib directory "graphics/"

The graphics library provides procedures that draw graphics images and text on
the screen. The library is OS dependent and is placed in the directory
"graphics" in the root directory of FreshLib.

The main conception of this library is ".raster" - represented by handle
object, where the drawing happens. 

The exact meaning for this object is
different for the different OSes — in Win32 it is named "device context", in
Linux it is "drawable" - window or pixmap.

--------------------

### "context.asm" library 


--------------------

### "draw.asm" library 

--------------------

### "fonts.asm" library 

--------------------

### "text.asm" library 

--------------------

### "images.asm" library 

--------------------

### "giflib.asm" library 

--------------------

### "backbuffer.asm" library 

--------------------

## FreshLib directory "mouse/" 

-------------------

### "mouse.asm" library 

------------------

## FreshLib directory "GUI/" 


This directory contains the libraries providing portable GUI for assembly
programming.

Note that these libraries are in very early stage of development, so the
description in this chapter is preliminary and probably will be changed in
one or another way in the near future.

The main idea behind the GUI library is to make one small OS dependent layer of
functions, that to serve as an interface between the OS and the OS independent
layer of the library.

The first will translate OS events, such as mouse, keyboard, timers etc to one
common standard of OS independent event handlers of the user interface
objects — windows, buttons and other widgets.

The biggest advantage of this approach is that the porting of the library
is very easy — most of the code is OS independent and only little part of it
have to be rewriten in order to port the whole library to a new OS.

The biggest drawback of this approach is the bigger size of the library,
because, with this architecture, all controls in the library have to be created
from scratch. It is impossible to use graphic controls that the OS provides —
particularly Win32 controls - buttons, simple text editors, labels, combo boxes
list and tree view controls etc.

This library is not aimed to use all complex GUI system of the target OS.
At first time, the goal of Fresh GUI library is to provide minimal, but decent
functionality that will do the job — writing portable GUI applications in
assembly language.

The GUI library is actually set of libraries.
These libraries widely use the FreshLib [FreshLibOOP.md][object oriented extension] 
because it is the best programming paradigm for programming GUI toolkits.

Because the GUI library is not finished it will not be documented here, but in
separate document and only when the state of the library is stable enough.


-------------------

### "main.asm" library. 

[#main.asm]

This library implements the procedures for the main program loop of the GUI application.
The modal dialogs procedure is also here.


[#Run]
;begin
    proc Run
;end
This procedure is the main program loop of the GUI application.
The procedure Run process all pending system events, then calls once the OnIdle
event handler of the [#TApplication] object and then sleeps until new events are
sent by the OS.

When the OS terminates the application — the procedure returns an exit code.

The programmer uses this procedure following way:
;begin
        stdcall Run
        push    eax             ; eax contains the exit code.

        FinalizeAll             ; free all resources.

        stdcall Terminate       ; the exit code is already in the stack.
;end

[#ShowModal]
;begin
    proc ShowModal, .pForm, .pParent
;end
Shows the form `[.pForm]` as a modal dialog window with parent window `[.pParent]` —
i.e. the parent window is disabled until the modal windows is visible.

The procedure returns the modal result in EAX. The modal result is also stored in
`TForm.ModalResult` field of the modal form.


[#ProcessSystemEvents]
;begin
    proc ProcessSystemEvents
;end
This procedure process the events generated by the OS. If there are waiting
events in the queue, the procedure reads them, translates them to FreshGUI
event data structures and calls the event handlers of the respective windows.

If there is no pending events in the queue, ProcessSystemEvents ends with CF=0

The second task this procedure serves is to detect the end of the application.
In this case it ends with CF=1.

This procedure is call from the main event loop of the application. ([#Run] procedure).
Also, the user can periodically call this procedure in order to not allow
hanging of the user interface during long processing of some data.


[#WaitForSystemEvent]
;begin
    proc WaitForSystemEvent
;end
This procedure waits until some system message is posted to the application
event queue. Then it exits. During the wait, very low CPU power is consumed
by the application.


-------------------


### "ObjTemplates.asm" library 

[#templates]

This library contains the template engine of FreshGUI.
The template engine provides creation of complex window structures with tree
layout from memory data structure, called template. The templates makes
creation of dialog windows containing children windows and non visual objects.

Templates can be visually created and edited. The template format used by
FreshLib is flexible and allows all parameters and fields of the objects to
be set to needed values during creation of the window.


The template is consisted from one or more data structures of type TObjTemplate,
defined following way:
;begin
    struct TObjTemplate
      .flags     dd  ?        
      .size      dd  ?         ; size of the instance structure.
      .vtable    dd  ?         ; pointer to the virtual methods table.
      .paramsize dd  ?
      .ptrVar    dd  ?
      .params:
    ends
;end
`.flags` — controls what is the place of the object in the whole tree structure.
Can accept one or more of the following values, combined with OR:

`tfChild`  — means the object is a child of the last object with tfParent set.

`tfParent` — means the given object is parent and there will be at least one next
TObjTemplate structure that will be a child object.

`tfEnd` — means the given object is the last child of its parent.
Note, that one object can be parent and child in the same time.
If the current template element is at the root level — the processing of
template stops, after creating the current element and all its children.

.size contains the size of the object instance structure.

.vtable - pointer to the object class virtual methods table. Actually this is the
object type (class) itself.

.paramsize — the size of the additional data to the end of the template.
Notice, that TObjTemplate is variable length structure, not fixed. sizeof.TObjTemplate
contains the size of the header part of the structure.

.ptrVar - pointer to dword variable that to accept the pointer to the created object.

.params — after the header fields there can be arbitrary count of dword pairs:
(paramID, Value) that to be set to the object during creation. This sequence
ends with dword $FFFFFFFF (-1) value for paramID.

Easy creation of templates is provided with macro ObjTemplate:

[#ObjTemplate]
;begin
    macro ObjTemplate  flags, class, name, [idparam]
;end
This macro allows use of string values for params and computes automatically
the values for TObjTemplate.paramsize;
The macro have following arguments:

* flags — set of (tfChild, tfParent, tfEnd) constants.

* class — the base name of the object class, for exampl TForm, TButton, TEdit, etc.

* name — label of the variable to receive the pointer to the created object.

* idparam — one or more object parameters values, defined as a pair `param = value`.
The value can be dword number or string constant. In the
case the parameter value is string, it will be automatically created in
the memory and the pointer to this string will be placed as a param value. The duplicated string
constants are defined only once.

One example of template structure:
;begin
    ObjTemplate  tfParent or tfEnd, TForm, frmMain,      \
                             visible = TRUE,             \
                             x = 100,                    \
                             y = 50,                     \
                             width = 640,                \
                             height = 480,               \
                             caption = 'Fresh portable Win32/Linux application test.'

      ObjTemplate  tfChild, Button, btnChild1,          \
                             visible = TRUE,             \
                             x = 64,                     \
                             y = 48,                     \
                             width = 64,                 \
                             height = 24,                \
                             caption = 'Button1',        \
                             OnClick = Button1Click

      ObjTemplate  tfChild or tfEnd, Button, btnChild2, \
                             x = 136,                    \
                             y = 48,                     \
                             width = 64,                 \
                             height = 24,                \
                             caption = 'Button2' ,       \
                             visible = TRUE
;end

The template engine provides one single procedure:

[#CreateFromTemplate]
;begin
    proc CreateFromTemplate, .ptrTemplate, .parent
;end

This procedure creates all objects from the template, pointed by `[.ptrTemplate]`
as a parent of `[.parent]` argument.

`.ptrTemplate` points to TObjTemplate structure.

`.parent` points to TObject descendant structure. In most cases it will be
actually descendant of TWindow or NULL if the created object is not a child
of any window.

Returns: *EBX* contains a pointer to the topmost of the created object
(it is first of the created objects)

All pointers of the objects are stored in the specified in the template
variables ( i.e. `[TObjTemplate.ptrVar]`)


------------------
