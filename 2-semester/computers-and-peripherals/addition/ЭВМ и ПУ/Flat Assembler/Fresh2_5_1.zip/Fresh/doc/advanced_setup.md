Setup manual
# Chapter 4 Fresh IDE setup

    The upcoming version 3.0 of Fresh IDE will be fully portable, but until then,
we have to use the Windows version of Fresh.

    Nevertheless, development of Windows and Linux applications in the same time is possible 
    and easy with the current version of Fresh.

    The good news are that Fresh IDE runs like a charm in [Wine].

    So, now (since v2.0.5) we have a choice - whatever OS we choose we can develop applications
for Linux and Windows, including editing, compiling, running and debugging. Of course we are
talking about GUI applications.

    The installation of Fresh is easy, but if we want to use the full potential of the IDE
some setup and adjustments are necessary. Let see how to setup Fresh IDE for work in Windows 
and Linux:

[wine] http://www.winehq.org/


## Windows setup

    In order to run Linux native applications inside Windows, Fresh uses special Linux
distribution - [andlinux].

    *andLinux* is complete Ubuntu distribution, that uses coLinux kernel in order to allow
running of Linux inside Windows OS.

[andLinux] http://andlinux.org
[andLinux download page] http://andlinux.org/downloads.php

    How to setup andLinux to work with Fresh?

### Download andLinux

    Download andLinux package from [andLinux download page]

    There are two packages: "KDE version" and "minimal/XFCE version" available. For use with
Fresh IDE, it is not important what version you will choose.

    KDE package is very big and very slow distribution that contains many bundled programs
and tools, but in general you will not need them. The size of KDE package is 500MB download
and 5GB installed.

    The XFCE package is relatively smaller and faster. Relatively means 200MB downloaded file
and 2GB installed on the disk.

    It is obvious that the right choice is to use XFCE package.

### Install andLinux

    Run the downloaded setup file and answer to the different questions of the
setup wizard:

    * coLinux version - choose the stable version (0.7.4 in my case) instead of latest (0.8.0) - 
we shall work with andLinux, not to play.

    * Memory size - 256MB RAM (or maybe more - if you can afford it).

    * Install XMing server on your primary screen.

    * Sound - you can enable or disable sound in Linux option - it is harmless although
it is one more running server.

    * Startup type + Panel - select *"run andLinux automatically as a NT service" + "use Windows shortcuts"*;
It is not very important, but can save you a little manual work and troubles later.

    * andLinux login - just select your user name and password for Linux root.

    * Windows File Access - it is important! - select *"using CoFS"*, no matter it is not recommended.

    * File Access Using CoFS - important! - create one new directory somewhere and select it to
be mount via CoFS. This will be the shared directory, visible from Windows and from Linux in the
same time.

    All other features you can choose freely or simply leave them to default state.

    When you start installation, the installer will try to install network driver.
It is possible Windows will protest and will atempt to mislead you by asking to not install
not certified driver. You must ignore these attempts and firmly click "install".

    After the installation of andLinux, you have to restart Windows and probably andLinux will
not run. :)

    It is because of the Windows firewall. All new network adapters are firewalled
by default. As long as installed adapter (named TAP-Colinux) is virtual and local, you will
not need any firewall, so, go to "Control panel/Windows firewall/Advanced" and uncheck
"TAP-Colinux" adapter from the list of adapters.

    Then you can run some Linux program - in the Windows tray, there is a andLinux menu icon
that have shortcuts to several Linux programs.


### Additional tools

    Install several additional Linux tools. You will need additionally debugger and
some decent terminal emulator. I choose xterm for terminal, because it is small and white by
default. ;)

    You can choose to use the built-in terminal named in the simple Linux manner:
"xfce4-terminal" and console debugger "gdb". In this case you can skip this step because these tools
are already installed.

    Start "Synaptic" - package manager for Ubuntu from the tray menu. You have to enter root
password you choose on install.

    When Synaptic is started, click "Reload" to refresh the package list from the network and
then use search to locate needed programs. I personally recommend "xterm" as terminal and "ddd"
as a GUI front end to "gdb".

    Well, I recommend "ddd" only because it is only Linux debugger that I was able to run under
andLinux and able to show disassembled code of the program.

    Mark selected programs for install, click on Apply button and wait until downloading and
installation.

    Here you can encounter only one problem - your computer is behind a proxy server.

    If the proxy is a normal proxy, you simply have to set its address and port in the
Synaptic preferences and it should work.

    Completely another story is when the proxy is MS ISA server configured with NTLM user
authorization.

    Most Linux programs can't work with such authorization and Synaptic is not an exception.

    Fortunately, there is a workaround of this situation. You need [ntlmaps] authorization 
proxy server.

    Setting up of this server is out of the scope of this article. On the ntlmaps home page you
can read complete documentation and explanations.

    OK, we are ready with andLinux. Now you have working copy of Ubuntu inside your Windows box.

    It's time to configure Fresh to run Linux applications inside andLinux. Continue with:

[ntlmaps] http://ntlmaps.sourceforge.net/

### Fresh IDE configuration.

    Run Fresh and open "Options|IDE options" dialog. Select "Debuggers and Emulators" page.
    Then select following directories and commands:

    * "andLinux directory" - the directory where you installed andLinux.

    * "andLinux shared directory" - shared directory you selected during andLinux installation.

    * "Linux debugger" - Enter "ddd" (or whatever debugger you choose).

    * "Linux terminal" - Enter: `xterm -hold +mesg -e` - the options are important.

    *And voila! You finished the configuration!*

    Now you can load the source of some Linux program (for example "Fresh/examples/XLib/XLib.fpr") and run it with
shift+F9 or load it in the debugger with shift+F8.

    Now Fresh IDE will detect when you compiled ELF executable and will run it in andLinux instead of
Windows. Of course, the Windows applications will be treated as usually.


## Linux setup

    Working in Linux needs Wine installation. Fresh is tested with v1.2 and 1.3 and works great.
You can skip some steps if they are already set.

### Install Wine

    Install Wine - use whatever package manager is good for you. Synaptic is the usual choice.
In the "Wine configuration|Graphics" panel, uncheck the option "Allow the window manager to decorate the windows".

### Install Fresh IDE

    Install Fresh IDE v2.0.5 or newer - you can use the installation package or ZIP
archive. It is better (at least for v2.0.5) to install Fresh IDE in "c:\" but you can put it at
whatever place you like.

### Debuggers

    Install whatever debugger you will use for Linux applications and OllyDbg for
Windows applications. (OllyDbg works in Wine).

    For Linux, personally I prefer [EDB] but any other is OK
including mentioned in the previous chapter "ddd" and "gdb".

[edb] http://www.codef00.com/projects#Debugger

### Configure Fresh IDE

Run Fresh IDE and if some paths are not set properly, set them manually in
"Options|IDE options" menu.

    You will need at least following directory aliases: "Fresh", "finc" and "lib" - set
them respectively to the Fresh main directory, Fresh "include" directory and "freshlib"
directory, both located in Fresh main directory. (As a rule, there is an auto setup of these
paths, so you don't to have to make it manually. But sometimes the algorithm fails)

    In order to work with FASM examples and programs, you can set manually "include" or any
other alias (environment variable) you prefer.

### External tools

    Set the paths to the external tools needed: (of course you have to install these
tools in advance).

    In "Options|IDE options|Debuggers and emulators" leave "andLinux directory" and
"andLinux shared directory" fields empty. (they are not needed when Fresh runs in Linux)

    Set "Linux debugger" field to binary file of the debugger you prefer. Add the needed
options to the line as well.

    For example, in my settings "Linux debugger" is set to `z:/usr/bin/edb --run`

    Set "Linux terminal" to preferred terminal. For example `z:/usr/bin/xterm -hold +mesg`.

    Set "Win32 external debugger" to OllyDbg.
In my case: `c:\Program files\OllyDebugger\Ollydbg.exe`.

    *All paths must be "dos style" (Note: Wine maps Linux file system to device Z: ).*

### Test it

    Try to compile and run some test applications both for Windows and Linux.
Ctrl+F9 should compile, Shift+F9 should run the application and Shift+F8 should load it
in the respective debugger. The type of the application should be automatically determined.

    *IMPORTANT NOTE:* The only known problem (for Fresh v2.0.5) is that the first time compiled
ELF is not set to be executable. So, you will get "access denied" message on run. The workaround
is to set the permissions manually from the file manager, or console "chmod" command. It is one
time procedure - the following compilations, runs and debugs should work properly.