"Fresh" project
(c)2003...2016 John Found, Fresh developement team

This file is in the root directory of the Fresh RAD IDE.
Fresh is FASM based, self compilable RAD IDE.

To browse and compile Fresh sources, use recent version of the
FASMW compiler or Fresh IDE itself.

Fresh IDE is free and open source project, distributed under the
terms of EUPL v.1.1; Read "License.txt" for details.

For more detailed information how to write applications with Fresh,
press Ctrl+F1 in Fresh IDE and read the help files.

For the sources look at: "source\" directory.

Also the repository with the project history and latest development
versions is on: http://fresh.flatassembler.net/fossil/repo/fresh

To get latest version of Fresh, visit Fresh home page: http://fresh.flatassembler.net

For FASM/FASMW information and downloads: http://flatassembler.net

To contact authors of Fresh and/or FASM: http://board.flatassembler.net

