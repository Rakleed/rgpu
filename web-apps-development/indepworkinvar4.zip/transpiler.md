# Транспиляция и сборка проекта с использованием директив импорта и экспорта в код с модульностью CommonJS

## main.js и number.js до транспиляции
![](https://tlgur.com/d/GLreqdE4)

![](https://tlgur.com/d/GZDZnbB4)

## package.json
![](https://tlgur.com/d/GXMD7K2g)

## Транспиляция
![](https://tlgur.com/d/8ekMYqlg)

## main.js и number.js после транспиляции
![](https://tlgur.com/d/GdBdYNM4)

![](https://tlgur.com/d/4x7ePDJg)

## Результат работы
![](https://tlgur.com/d/8ekMY3eg)
