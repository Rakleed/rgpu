# Сборка проекта с помощью бандлера Webpack
## webpack.config
![](https://tlgur.com/d/GPMDKJYg)

## package.json
![](https://tlgur.com/d/gwkBrnng)

## До сборки
![](https://tlgur.com/d/4zZdrRE4)

![](https://tlgur.com/d/g3vR9rXG)

## Сборка
![](https://tlgur.com/d/8KoBa2M8)

## Результат работы
![](https://tlgur.com/d/4Rabnwkg)
