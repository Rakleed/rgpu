const sqlite3 = require('sqlite3').verbose();

// open the database
let db = new sqlite3.Database('./db.db', sqlite3.OPEN_READWRITE, (err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Connected to the database.');
});

// db.run('CREATE TABLE items(ItemID,ItemName)');

 db.run(`INSERT INTO items(ItemID,ItemName) VALUES(?,?)`, [51, 'Sample Item'], function(err) {
    if (err) {
      return console.log(err.message);
    }
    // get the last insert id
    console.log(`A row has been inserted with rowid ${this.lastID}`);
  });

db.serialize(() => {
  db.each(`SELECT ItemID as id,
                  ItemName as name
           FROM items`, (err, row) => {
    if (err) {
      console.error(err.message);
    }
    console.log(row.id + "\t" + row.name);
  });
});


db.close((err) => {
  if (err) {
    console.error(err.message);
  }
  console.log('Close the database connection.');
});