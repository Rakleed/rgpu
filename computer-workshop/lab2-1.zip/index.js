const http = require('http')

http.createServer((req, res) => {
  
  if (req.method == 'POST') {

    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.end('No POST, please!');

  } else {

    let [, op, a, b] = req.url.split('/');
    [a, b] = [parseFloat(a), parseFloat(b)]
    if (op == 'add')
      re = a + b
    else if (op == 'sub')
      re = a - b
    else if (op == 'mul')
      re = a * b
    else if (op == 'div')
      re = a / b
    else
      re = 'Unknown operation'

    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.end(JSON.stringify({ 'operation': op, 'a': a, 'b': b, 'result': re  }));

  }
  
}).listen(8080);
