import Namer from './namer2';
const person = new Namer();
console.log(person.getFullName());
