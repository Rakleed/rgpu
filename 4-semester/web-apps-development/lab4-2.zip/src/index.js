import React, { Component } from "react";
import { render } from "react-dom";
import Hello from "./Hello";
import "./style.css";
import moment from "moment";
import DatePicker from "material-ui/DatePicker";
import MuiThemeProvider from "material-ui/styles/MuiThemeProvider";

class App extends Component {
  constructor() {
    super();
    this.state = {
      val: "some time"
    };
  }

  render() {
    return (
      <div>
        <Hello name={this.state.val} />
        <DatePicker
          onChange={(n = null, date) =>
            this.setState({
              val: moment()
                .subtract(moment(date).toObject())
                .format("YY-MM-DD HH:mm:ss")
            })
          }
          floatingLabelText="Pick a date"
        />
      </div>
    );
  }
}

render(
  <MuiThemeProvider>
    <App />
  </MuiThemeProvider>,
  document.getElementById("root")
);
// console.log(moment.now('DD-MM-YYYY'))
// moment(date).format('DD-MM-YYYY')
