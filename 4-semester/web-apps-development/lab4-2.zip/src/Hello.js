import React from "react";

export default ({ name }) => <h1>It passed {name}!</h1>;
