import moment from 'moment';
import name from './name';
console.log(name);
console.log(moment.unix('1500514362').format('DD.MM.YYYY HH:mm:ss'));
