export default class {
    first = 'Ilya';
    last = 'Goss';

    getFullName() {
        return `${this.first} ${this.last}`;
    }
}
