import sqlite3

conn = sqlite3.connect("example.db")
c = conn.cursor()


def insert():
    values = [("2020-02-20", "BUY", "APL", 100, 42.00)]
    try:
        c.executemany(f'INSERT INTO stocks VALUES (?, ?, ?, ?, ?)', values)
        conn.commit()
    except sqlite3.Error as error:
        print("Не получилось обновить таблицу ", error)


def update():
    price = 10.4
    symbol = "APL"
    try:
        c.execute('UPDATE stocks SET price = ? WHERE symbol = ?', (price, symbol))
        conn.commit()
    except sqlite3.Error as error:
        print("Не получилось обновить таблицу", error)


def delete():
    try:
        c.execute("DELETE FROM stocks WHERE price = 56.0")
        conn.commit()
    except sqlite3.Error as error:
        print("Не получилось обновить таблицу ", error)


def main():
    print("Хотите просто увидеть содержимое таблицы? (Y/N)")
    answer = input()
    if answer == "n":
        insert()
        update()
        delete()
    if answer == "y":
        for row in c.execute('SELECT * FROM stocks ORDER BY price'):
            print(row)
    if answer != "y" and answer != "n":
        print("Вы ввели неверные данные.")
    for row in c.execute('SELECT * FROM stocks ORDER BY price'):
        print(row)


main()
conn.close()
