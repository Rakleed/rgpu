"""
    Автор: Моисеенко Павел, группа № 1, подгруппа № 2.

    ИСР 1.1. Задание: разработать программу с реализацией функции для
    считывания json-данных из файла и вывод их в табличном виде на
    экран. Реализовать базовый синтаксис для обработки исключений
    (try .. except).

"""

import json

try:
    with open('file.json') as f:
        data_dict = json.load(f)
except FileNotFoundError as e:
    print(e)

try:
    with open('file.json') as f:
        data_dict = json.load(r)
except NameError as e:
    print(e)

try:
    for element in range(len(data_dict)):
        temp = data_dit[element]
        res = string.format(**temp)
        table.append(res)
except NameError as e:
    print(e)


def json_table(file):
    with open(file) as f:
        data_dict = json.load(f)
    table = []
    string = '| {id:^3} | {first_name:^10} | {last_name:^15} | {email:^30} | {gender:^6} | {ip_address:^16} |'
    t_caption = '| {:^3} | {:^10} | {:^15} | {:^30} | {:^6} | {:^16} |'.format('id', 'first_name', 'last_name', 'email',
                                                                               'gender', 'ip_address')
    header = '-' * len(t_caption)
    table.append(header)
    table.append(t_caption)
    table.append(header)
    for el in range(len(data_dict)):
        temp = data_dict[el]
        res = string.format(**temp)
        table.append(res)
    table.append(header)
    return table


def main():
    a = json_table('file.json')
    for element in a:
        print(element)


main()
