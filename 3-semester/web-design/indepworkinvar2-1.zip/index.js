const a = 1;
const b = 2;
let c = a + b;
console.log(c);
