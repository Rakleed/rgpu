const a1 = 'Bye';
const a2 = 'Hello';
let bst = 'bye'
if (bst == 'Hello'){
    console.log('Yes');
} else {
    console.log('No');
    bst = 'Javascript';
    console.log(bst);
    console.log('Yes');
}
